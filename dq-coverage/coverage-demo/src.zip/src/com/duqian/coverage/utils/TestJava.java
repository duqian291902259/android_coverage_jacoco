package com.duqian.coverage.utils;

import android.util.Log;

/**
 * Description:test
 * <p>
 * Created by 杜乾 on 2024/2/7 - 16:05.
 * E-mail: duqian@flatincbr.com
 */
public class TestJava {
    public static void  test(){
        Log.d("dq-jacoco","test cc coverage");
    }
}
